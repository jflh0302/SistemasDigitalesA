`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06.10.2026 10:02:41
// Design Name: 
// Module Name: Top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Top(
    
`timescale 1ns / 1ps

    input  logic clk,
    input  logic reset,
    input  logic boton,
    output logic detect_mealy,
    output logic detect_moore,
    output logic led_ready
);

    logic s_out;

    // Divisor de frecuencia
    reloj #(
        .N(25)
    ) DIV (
        .clk(clk),
        .reset(reset),
        .s_out(s_out)
    );
 // LED encendido durante la fase de preparacion
    assign led_ready = s_out;
    // Maquina Mealy
    maqmealy MEALY (
        .clk(s_out),
        .reset(reset),
        .enable(1'b1),
        .data_in(boton),
        .detect(detect_mealy)
    );

    // Maquina Moore
    maqmoore MOORE (
        .clk(s_out),
        .reset(reset),
        .enable(1'b1),
        .data_in(boton),
        .detect(detect_moore)
    );

endmodule

