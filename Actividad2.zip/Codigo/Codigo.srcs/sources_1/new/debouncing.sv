`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05.11.2026 10:27:46
// Design Name: 
// Module Name: debouncing
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module debouncing #(
    parameter DEBOUNCE_CYCLES = 4
)(
    input  logic clk,
    input  logic reset,
    input  logic button_in,
    output logic button_out
);

    logic sync_1;
    logic sync_2;

    logic [31:0] counter;

    always_ff @(posedge clk or posedge reset) begin

        if (reset) begin
            sync_1    <= 1'b0;
            sync_2    <= 1'b0;
            counter   <= 0;
            button_out <= 1'b0;
        end

        else begin

            // Sincronizacion de la entrada
            sync_1 <= button_in;
            sync_2 <= sync_1;

            // Verificar estabilidad
            if (sync_2 == button_out) begin
                counter <= 0;
            end

            else begin

                if (counter == DEBOUNCE_CYCLES - 1) begin
                    button_out <= sync_2;
                    counter <= 0;
                end

                else begin
                    counter <= counter + 1'b1;
                end

            end
        end
    end

endmodule
