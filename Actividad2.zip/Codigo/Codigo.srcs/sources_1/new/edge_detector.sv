
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05.11.2026 09:53:32
// Design Name: 
// Module Name: edge_detector
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



`timescale 1ns / 1ps

module edge_detector(
    input  logic clk,
    input  logic reset,
    input  logic signal_in,
    output logic tick
);

    logic signal_prev;

    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            signal_prev <= 1'b0;
            tick        <= 1'b0;
        end
        else begin
            signal_prev <= signal_in;
            tick <= signal_in & ~signal_prev;
        end
    end

endmodule

