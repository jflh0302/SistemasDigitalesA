`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 14.10.2026 13:39:16
// Design Name: 
// Module Name: Reloj
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////





module reloj #(
    parameter N = 25
)(
    input  logic clk,
    input  logic reset,
    output logic s_out
);

    logic [N-1:0] state_reg;
    logic [N-1:0] state_next;

    always_ff @(posedge clk or posedge reset) begin
        if (reset)
            state_reg <= '0;
        else
            state_reg <= state_next;
    end

    assign state_next = state_reg + 1'b1;
    assign s_out = state_reg[N-1];

endmodule

