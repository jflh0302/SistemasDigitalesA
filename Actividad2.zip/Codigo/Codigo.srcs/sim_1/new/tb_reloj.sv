
`timescale 1ns / 1ps

module tb_reloj;

    logic clk;
    logic reset;
    logic s_out;

    // Instancia del divisor de frecuencia
    reloj #(
        .N(4)
    ) DUT (
        .clk(clk),
        .reset(reset),
        .s_out(s_out)
    );

    // Generador de reloj: periodo de 10 ns
    always #5 clk = ~clk;

    // Secuencia de prueba
    initial begin
        clk = 0;
        reset = 1;

        #20;
        reset = 0;

        // Esperar para observar varios cambios
        #400;

        $finish;
    end

endmodule

