`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05.11.2026 09:57:12
// Design Name: 
// Module Name: tb_edge_detector
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_edge_detector;

logic clk;
logic reset;
logic signal_in;
logic tick;

// Instancia del circuito
edge_detector DUT (
.clk(clk),
.reset(reset),
.signal_in(signal_in),
.tick(tick)
);

// Generador de reloj de 10 ns
always #5 clk = ~clk;

initial begin

// Inicializacion
clk = 0;
reset = 1;
signal_in = 0;

// Mantener reset
#20;
reset = 0;

// Primer flanco de subida
#20;
signal_in = 1;

// Mantener entrada en 1
#40;

// Regresar a cero
signal_in = 0;

#30;

// Segundo flanco de subida
signal_in = 1;

#40;

// Regresar a cero
signal_in = 0;

#30;

$finish;

end

endmodule

