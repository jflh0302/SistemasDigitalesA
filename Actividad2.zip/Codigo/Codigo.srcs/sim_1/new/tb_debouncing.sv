`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05.11.2026 10:32:14
// Design Name: 
// Module Name: tb_debouncing
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb_debouncing;

logic clk;
    logic reset;
    logic button_in;
    logic button_out;

// Instancia del circuito
    debouncing #(
        .DEBOUNCE_CYCLES(4)
    ) DUT (
        .clk(clk),
        .reset(reset),
        .button_in(button_in),
        .button_out(button_out)
    );

// Generador de reloj: periodo de 10 ns
    always #5 clk = ~clk;

    initial begin

// Inicializacion
        clk = 0;
        reset = 1;
        button_in = 0;

#20;
        reset = 0;

// Primeros rebotes al presionar
        #20 button_in = 1;
        #10 button_in = 0;
        #10 button_in = 1;
        #10 button_in = 0;
        #10 button_in = 1;

// Mantener presionado el boton
        #100;

// Rebotes al soltar el boton
        button_in = 0;
        #10 button_in = 1;
        #10 button_in = 0;
        #10 button_in = 1;
        #10 button_in = 0;

// Mantener el boton liberado
        #100;

        $finish;

    end

endmodule

